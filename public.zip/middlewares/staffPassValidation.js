import Staff from "../models/staff.js";

const jsonWebToken = async(req, res, next) => {
    const staffkey = req.header('staffkey');

    if (!staffkey) {
        return res.status(400).json({
            error: 'Acceso denegado.',
        });
    }

    try {
        if (!user || !user.status) {
            return res.status(404).json({
                error: 'Token inválido'
            });
        }

        req.user = user;

        next();
    } catch (error) {
        console.log(error);
        res.status(401).json({
            error: 'Token inválido'
        })
    }
}

export default jsonWebToken;